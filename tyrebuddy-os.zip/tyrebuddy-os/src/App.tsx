import React, { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from './db/db';
import { initializeDatabaseIfEmpty, DEFAULT_ORG_ID } from './db/seed';
import { formatINR, formatDate, calculateGSTFromInclusive } from './utils/formatters';
import {
  ProductVariant,
  Product,
  Customer,
  WarehouseType,
  GSTRate,
  PaymentStatus,
} from './types';
import {
  Package,
  FileText,
  Users,
  ShieldCheck,
  HardDrive,
  Download,
  Upload,
  PlusCircle,
  CheckCircle2,
  AlertCircle,
  Truck,
  RotateCcw,
} from 'lucide-react';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'billing' | 'inventory' | 'customers' | 'journal' | 'audit'>('billing');
  const [dbReady, setDbReady] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Live queries from IndexedDB
  const org = useLiveQuery(() => db.organizations.get(DEFAULT_ORG_ID));
  const products = useLiveQuery(() => db.products.where('is_deleted').equals(0).or('is_deleted').equals(undefined).toArray()) || [];
  const variants = useLiveQuery(() => db.variants.toArray()) || [];
  const customers = useLiveQuery(() => db.customers.where('is_deleted').equals(0).or('is_deleted').equals(undefined).toArray()) || [];
  const stockEntries = useLiveQuery(() => db.stock_journal.orderBy('created_at').reverse().toArray()) || [];
  const auditLogs = useLiveQuery(() => db.audit_log.orderBy('timestamp').reverse().limit(50).toArray()) || [];
  const orders = useLiveQuery(() => db.orders.orderBy('created_at').reverse().toArray()) || [];

  // Billing Quick State
  const [selectedCustomer, setSelectedCustomer] = useState<string>('cust_b2c_walkin');
  const [selectedVariant, setSelectedVariant] = useState<string>('');
  const [itemQty, setItemQty] = useState<number>(1);
  const [customPrice, setCustomPrice] = useState<number>(0);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('Paid');
  const [cartItems, setCartItems] = useState<Array<{
    variant: ProductVariant;
    qty: number;
    sellingPriceInclusive: number;
    taxableValue: number;
    gstRate: GSTRate;
    cgst: number;
    sgst: number;
    igst: number;
    totalAmount: number;
  }>>([]);

  // Initialize DB on launch
  useEffect(() => {
    initializeDatabaseIfEmpty().then(() => {
      setDbReady(true);
    });
  }, []);

  // Update custom price when variant selected
  useEffect(() => {
    if (selectedVariant) {
      const v = variants.find(item => item.id === selectedVariant);
      if (v) {
        setCustomPrice(v.selling_price_inclusive);
      }
    }
  }, [selectedVariant, variants]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Add Item to Billing Cart
  const handleAddToCart = () => {
    if (!selectedVariant || itemQty <= 0) return;
    const variant = variants.find(v => v.id === selectedVariant);
    if (!variant) return;

    const cust = customers.find(c => c.id === selectedCustomer);
    const stateCode = cust?.state_code || '24';

    const calculation = calculateGSTFromInclusive(customPrice, itemQty, variant.gst_rate, stateCode);

    setCartItems(prev => [
      ...prev,
      {
        variant,
        qty: itemQty,
        sellingPriceInclusive: customPrice,
        taxableValue: calculation.taxableValue,
        gstRate: variant.gst_rate,
        cgst: calculation.cgst,
        sgst: calculation.sgst,
        igst: calculation.igst,
        totalAmount: calculation.totalGross,
      },
    ]);

    setSelectedVariant('');
    setItemQty(1);
    setCustomPrice(0);
    showNotification('Item added to bill');
  };

  // Create Order & Immutable Stock Journal Out
  const handleCompleteOrder = async () => {
    if (cartItems.length === 0) return;
    const cust = customers.find(c => c.id === selectedCustomer);
    if (!cust) return;

    const orderNumber = await db.getNextSequence(DEFAULT_ORG_ID, 'ORDER');
    const invoiceNumber = await db.getNextSequence(DEFAULT_ORG_ID, 'INVOICE');

    const totalTaxable = cartItems.reduce((acc, i) => acc + i.taxableValue, 0);
    const totalCgst = cartItems.reduce((acc, i) => acc + i.cgst, 0);
    const totalSgst = cartItems.reduce((acc, i) => acc + i.sgst, 0);
    const totalIgst = cartItems.reduce((acc, i) => acc + i.igst, 0);
    const grandTotal = cartItems.reduce((acc, i) => acc + i.totalAmount, 0);

    const isPaid = paymentStatus === 'Paid';
    const amountReceived = isPaid ? grandTotal : 0;
    const balanceDue = grandTotal - amountReceived;

    await db.transaction('rw', [db.orders, db.stock_journal, db.audit_log], async () => {
      // 1. Create Order
      await db.orders.add({
        id: `ORD_${Date.now()}`,
        org_id: DEFAULT_ORG_ID,
        order_number: orderNumber,
        invoice_number: invoiceNumber,
        customer_id: cust.id,
        customer_name: cust.name,
        customer_type: cust.type,
        customer_phone: cust.phone,
        customer_state_code: cust.state_code,
        is_inter_state: cust.state_code !== '24',
        warehouse: 'Own',
        items: cartItems.map(item => ({
          id: `item_${Date.now()}_${item.variant.id}`,
          variant_id: item.variant.id,
          product_name: item.variant.title,
          sku: item.variant.sku,
          hsn_code: item.variant.hsn_code,
          quantity: item.qty,
          selling_price_inclusive: item.sellingPriceInclusive,
          taxable_value: item.taxableValue,
          gstRate: item.gstRate,
          cgst_amount: item.cgst,
          sgst_amount: item.sgst,
          igst_amount: item.igst,
          total_tax_amount: item.cgst + item.sgst + item.igst,
          total_amount: item.totalAmount,
        })),
        subtotal_taxable: totalTaxable,
        total_cgst: totalCgst,
        total_sgst: totalSgst,
        total_igst: totalIgst,
        total_tax: totalCgst + totalSgst + totalIgst,
        total_amount: grandTotal,
        payment_status: paymentStatus,
        amount_received: amountReceived,
        balance_due: balanceDue,
        delivery_status: 'Delivered',
        order_source: 'Store POS',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

      // 2. Rule 3: Stock journal immutable - append SALE_OUT rows
      for (const item of cartItems) {
        await db.stock_journal.add({
          id: `JRN_${Date.now()}_${item.variant.id}`,
          org_id: DEFAULT_ORG_ID,
          entry_number: `JRN-SALE-${orderNumber}`,
          entry_type: 'SALE_OUT',
          variant_id: item.variant.id,
          warehouse: 'Own',
          quantity: -Math.abs(item.qty),
          unit_cost: item.variant.cost_price,
          reference_type: 'ORDER',
          reference_id: orderNumber,
          notes: `Sold in invoice ${invoiceNumber}`,
          created_at: new Date().toISOString(),
        });
      }
    });

    setCartItems([]);
    showNotification(`Invoice ${invoiceNumber} created! Stock updated.`);
  };

  // Rule 7: Never lose data - Export full JSON to D: drive
  const handleExportBackupToDDrive = async () => {
    try {
      const backup = await db.exportFullBackup(DEFAULT_ORG_ID);
      const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(backup, null, 2))}`;
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', jsonString);
      const todayStr = new Date().toISOString().split('T')[0];
      downloadAnchor.setAttribute('download', `Tyrebuddy_Backup_D_Drive_${todayStr}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showNotification('Backup downloaded! Save it to your D: drive folder.');
    } catch (err: any) {
      alert(`Export failed: ${err.message}`);
    }
  };

  // Import Backup
  const handleImportBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const content = JSON.parse(e.target?.result as string);
        await db.importFullBackup(content);
        showNotification('Data successfully restored from backup file!');
      } catch (err: any) {
        alert(`Restore failed: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  // Calculate live stock per variant in Own warehouse
  const getStockCount = (variantId: string, warehouse: WarehouseType = 'Own') => {
    const entries = stockEntries.filter(e => e.variant_id === variantId && e.warehouse === warehouse);
    return entries.reduce((acc, curr) => acc + curr.quantity, 0);
  };

  if (!dbReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white font-mono">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-emerald-400 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm tracking-wider">INITIALIZING TYREBUDDY BUSINESS OS...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-100 text-slate-800">
      {/* Top Header */}
      <header className="bg-slate-900 text-white border-b border-slate-800 px-4 py-3 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="bg-emerald-500 text-slate-950 font-black px-2.5 py-1 rounded text-lg tracking-wider">
              TYREBUDDY
            </div>
            <div>
              <h1 className="text-base font-bold leading-tight">{org?.name || 'Tyrebuddy Bicycle Accessories'}</h1>
              <p className="text-xs text-slate-400">
                GSTIN: <span className="text-emerald-400 font-mono font-medium">{org?.gstin}</span> | State: Gujarat (24)
              </p>
            </div>
          </div>

          {/* D: Drive & Offline Indicator */}
          <div className="flex items-center space-x-2 text-xs">
            <div className="flex items-center space-x-1.5 bg-slate-800 border border-slate-700 px-2.5 py-1.5 rounded text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-medium">100% Offline (IndexedDB)</span>
            </div>

            <button
              onClick={handleExportBackupToDDrive}
              className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded font-medium shadow-sm transition"
              title="Backup current database for D: Drive storage"
            >
              <HardDrive className="w-3.5 h-3.5" />
              <span>Backup to D:</span>
            </button>

            <label className="flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 px-2.5 py-1.5 rounded cursor-pointer transition">
              <Upload className="w-3.5 h-3.5" />
              <span>Restore</span>
              <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
            </label>
          </div>
        </div>
      </header>

      {/* Notifications */}
      {notification && (
        <div className="bg-emerald-600 text-white text-xs text-center py-2 px-4 font-medium flex items-center justify-center space-x-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>{notification}</span>
        </div>
      )}

      {/* Navigation Tabs (Mobile-First scrollable) */}
      <nav className="bg-white border-b border-slate-200 px-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex space-x-1 overflow-x-auto py-2 scrollbar-none text-sm font-semibold">
          <button
            onClick={() => setActiveTab('billing')}
            className={`px-3.5 py-2 rounded-lg flex items-center space-x-2 transition whitespace-nowrap ${
              activeTab === 'billing' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>POS Billing</span>
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-3.5 py-2 rounded-lg flex items-center space-x-2 transition whitespace-nowrap ${
              activeTab === 'inventory' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Inventory & Warehouses</span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`px-3.5 py-2 rounded-lg flex items-center space-x-2 transition whitespace-nowrap ${
              activeTab === 'customers' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Customers (B2B / B2C)</span>
          </button>

          <button
            onClick={() => setActiveTab('journal')}
            className={`px-3.5 py-2 rounded-lg flex items-center space-x-2 transition whitespace-nowrap ${
              activeTab === 'journal' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Stock Journal (FIFO)</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-2 rounded-lg flex items-center space-x-2 transition whitespace-nowrap ${
              activeTab === 'audit' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Audit Trail</span>
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto w-full p-4 flex-1">
        {/* ==================== TAB 1: POS BILLING ==================== */}
        {activeTab === 'billing' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left: Item Picker & Customer */}
            <div className="lg:col-span-7 space-y-4">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
                <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wide flex items-center justify-between">
                  <span>Customer & Location</span>
                  <span className="text-xs font-normal text-slate-500">
                    Retailer: Gujarat (Code 24)
                  </span>
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Select Customer</label>
                    <select
                      value={selectedCustomer}
                      onChange={(e) => setSelectedCustomer(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    >
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.type} - {c.state_code === '24' ? 'Gujarat' : 'Other'})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Customer Terms</label>
                    {(() => {
                      const c = customers.find(item => item.id === selectedCustomer);
                      return (
                        <div className="text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-600">
                          {c?.type === 'B2B' ? (
                            <span className="font-medium text-emerald-700">
                              B2B: GSTIN {c.gstin || 'N/A'} • 30-Day Credit Term
                            </span>
                          ) : (
                            <span className="font-medium text-blue-700">
                              B2C: Retail Customer • Same-Day Payment
                            </span>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>

              {/* Add Product Card */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
                <h2 className="text-sm font-bold text-slate-700 uppercase tracking-wide">Add Product to Bill</h2>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Product Variant</label>
                    <select
                      value={selectedVariant}
                      onChange={(e) => setSelectedVariant(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    >
                      <option value="">-- Choose Tyre / Accessory Variant --</option>
                      {variants.map((v) => {
                        const stock = getStockCount(v.id, 'Own');
                        return (
                          <option key={v.id} value={v.id}>
                            {v.title} | Stock: {stock} | Price: {formatINR(v.selling_price_inclusive)}
                          </option>
                        );
                      })}
                    </select>
                  </div>

                  {selectedVariant && (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1">
                      <div>
                        <label className="text-xs font-semibold text-slate-600 block mb-1">
                          Inclusive Price (₹)
                        </label>
                        <input
                          type="number"
                          value={customPrice}
                          onChange={(e) => setCustomPrice(Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                        />
                        <span className="text-[10px] text-slate-400">GST-inclusive (Auto back-calc)</span>
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-slate-600 block mb-1">Quantity</label>
                        <input
                          type="number"
                          min="1"
                          value={itemQty}
                          onChange={(e) => setItemQty(Math.max(1, Number(e.target.value)))}
                          className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                        />
                      </div>

                      <div className="flex items-end">
                        <button
                          onClick={handleAddToCart}
                          className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2 px-3 rounded-lg text-sm transition flex items-center justify-center space-x-1.5 shadow"
                        >
                          <PlusCircle className="w-4 h-4" />
                          <span>Add to Bill</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Previous Orders Mini List */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Recent Invoices</h3>
                <div className="divide-y divide-slate-100 text-xs">
                  {orders.slice(0, 4).map((o) => (
                    <div key={o.id} className="py-2 flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-slate-800">{o.invoice_number || o.order_number}</p>
                        <p className="text-[11px] text-slate-500">{o.customer_name} • {formatDate(o.created_at)}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-slate-900">{formatINR(o.total_amount)}</p>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          o.payment_status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {o.payment_status}
                        </span>
                      </div>
                    </div>
                  ))}
                  {orders.length === 0 && (
                    <p className="text-slate-400 py-3 text-center">No invoices generated yet.</p>
                  )}
                </div>
              </div>
            </div>

            {/* Right: Cart & Tally-Style Invoice Summary */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col h-full">
                <h2 className="text-sm font-bold text-slate-800 border-b pb-2 flex items-center justify-between">
                  <span>Current Bill Summary</span>
                  <span className="text-xs font-normal bg-slate-100 px-2 py-0.5 rounded text-slate-600">
                    {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'}
                  </span>
                </h2>

                {/* Items Table */}
                <div className="flex-1 my-3 overflow-x-auto">
                  {cartItems.length === 0 ? (
                    <div className="text-center py-10 text-slate-400 space-y-2">
                      <FileText className="w-8 h-8 mx-auto stroke-1" />
                      <p className="text-xs">No items in bill yet. Select an item and click Add.</p>
                    </div>
                  ) : (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b text-slate-500 font-semibold">
                          <th className="py-1.5">Item</th>
                          <th className="py-1.5 text-center">Qty</th>
                          <th className="py-1.5 text-right">Rate</th>
                          <th className="py-1.5 text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {cartItems.map((item, idx) => (
                          <tr key={idx} className="text-slate-700">
                            <td className="py-2 pr-1">
                              <p className="font-semibold text-slate-900">{item.variant.title}</p>
                              <span className="text-[10px] text-slate-400">HSN: {item.variant.hsn_code} | GST: {item.gstRate}%</span>
                            </td>
                            <td className="py-2 text-center font-medium">{item.qty}</td>
                            <td className="py-2 text-right">{formatINR(item.sellingPriceInclusive)}</td>
                            <td className="py-2 text-right font-bold">{formatINR(item.totalAmount)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>

                {/* Tax Breakdown & Plain-Language Totals */}
                {cartItems.length > 0 && (
                  <div className="border-t border-slate-200 pt-3 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Taxable Value (Before Tax):</span>
                      <span className="font-mono">{formatINR(cartItems.reduce((acc, i) => acc + i.taxableValue, 0))}</span>
                    </div>

                    {/* Intra-state (CGST + SGST) vs Inter-state (IGST) */}
                    {(() => {
                      const cust = customers.find(c => c.id === selectedCustomer);
                      const isGujarat = cust?.state_code === '24';
                      const totalCgst = cartItems.reduce((acc, i) => acc + i.cgst, 0);
                      const totalSgst = cartItems.reduce((acc, i) => acc + i.sgst, 0);
                      const totalIgst = cartItems.reduce((acc, i) => acc + i.igst, 0);

                      return isGujarat ? (
                        <>
                          <div className="flex justify-between text-slate-600">
                            <span>CGST (Intra-state 50%):</span>
                            <span className="font-mono">{formatINR(totalCgst)}</span>
                          </div>
                          <div className="flex justify-between text-slate-600">
                            <span>SGST (Intra-state 50%):</span>
                            <span className="font-mono">{formatINR(totalSgst)}</span>
                          </div>
                        </>
                      ) : (
                        <div className="flex justify-between text-slate-600">
                          <span>IGST (Inter-state):</span>
                          <span className="font-mono">{formatINR(totalIgst)}</span>
                        </div>
                      );
                    })()}

                    <div className="flex justify-between text-sm font-bold text-slate-900 border-t border-dashed pt-2">
                      <span>Total Bill Amount:</span>
                      <span className="text-emerald-700 font-mono text-base">
                        {formatINR(cartItems.reduce((acc, i) => acc + i.totalAmount, 0))}
                      </span>
                    </div>

                    {/* Rule 1: Plain Language Payment Terms */}
                    <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 space-y-2 mt-2">
                      <label className="text-[11px] font-bold text-slate-700 block">Payment Terms</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setPaymentStatus('Paid')}
                          className={`py-1.5 px-2 rounded text-xs font-semibold border ${
                            paymentStatus === 'Paid'
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          Paid (Money Received)
                        </button>
                        <button
                          type="button"
                          onClick={() => setPaymentStatus('Unpaid')}
                          className={`py-1.5 px-2 rounded text-xs font-semibold border ${
                            paymentStatus === 'Unpaid'
                              ? 'bg-amber-600 text-white border-amber-600'
                              : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          Credit / Udhar (Pending)
                        </button>
                      </div>
                    </div>

                    {/* Generate Invoice Button */}
                    <button
                      onClick={handleCompleteOrder}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-lg text-sm shadow transition flex items-center justify-center space-x-2 mt-3"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Complete Bill & Generate Invoice</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 2: INVENTORY & WAREHOUSES ==================== */}
        {activeTab === 'inventory' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">Stock & Warehouses</h2>
                <p className="text-xs text-slate-500">
                  Warehouses: Own • Damaged • Returns • Amazon FBA
                </p>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                    <tr>
                      <th className="p-3">Product & SKU</th>
                      <th className="p-3">Attributes</th>
                      <th className="p-3">HSN / GST</th>
                      <th className="p-3 text-right">Cost Price</th>
                      <th className="p-3 text-right">Retail Price (Incl.)</th>
                      <th className="p-3 text-center">Own Stock</th>
                      <th className="p-3 text-center">Damaged</th>
                      <th className="p-3 text-center">FBA</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {variants.map((v) => (
                      <tr key={v.id} className="hover:bg-slate-50/50">
                        <td className="p-3">
                          <p className="font-bold text-slate-900">{v.title}</p>
                          <span className="font-mono text-[11px] text-slate-500">{v.sku}</span>
                        </td>
                        <td className="p-3">
                          {/* Rule 4: Variant attributes stored as JSON key-value */}
                          <div className="flex flex-wrap gap-1">
                            {Object.entries(v.attributes || {}).map(([k, val]) => (
                              <span key={k} className="bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded text-[10px] text-slate-600 font-medium">
                                {k}: {val}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="p-3 font-mono">
                          {v.hsn_code} <span className="text-emerald-700 font-bold">({v.gst_rate}%)</span>
                        </td>
                        <td className="p-3 text-right font-mono">{formatINR(v.cost_price)}</td>
                        <td className="p-3 text-right font-mono font-bold text-slate-900">
                          {formatINR(v.selling_price_inclusive)}
                        </td>
                        <td className="p-3 text-center">
                          <span className="font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                            {getStockCount(v.id, 'Own')}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <span className="text-red-700 bg-red-50 px-2 py-0.5 rounded">
                            {getStockCount(v.id, 'Damaged')}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                            {getStockCount(v.id, 'Amazon FBA')}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 3: CUSTOMERS ==================== */}
        {activeTab === 'customers' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex justify-between items-center">
              <div>
                <h2 className="text-base font-bold text-slate-900">Customer Directory</h2>
                <p className="text-xs text-slate-500">B2B (GSTIN & 30-Day Credit) • B2C (Immediate Payment)</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {customers.map((c) => (
                <div key={c.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-slate-900">{c.name}</h3>
                    <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                      c.type === 'B2B' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {c.type}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">Phone: {c.phone}</p>
                  <p className="text-xs text-slate-600">Location: {c.city}, {c.state} (Code: {c.state_code})</p>
                  {c.gstin && (
                    <p className="text-xs font-mono text-slate-700">GSTIN: {c.gstin}</p>
                  )}
                  <div className="pt-2 border-t text-xs flex justify-between text-slate-500 font-medium">
                    <span>Terms: {c.type === 'B2B' ? '30 Days Credit' : 'Same-day Settlement'}</span>
                    {c.discount_percentage ? <span>Negotiated Discount: {c.discount_percentage}%</span> : null}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== TAB 4: STOCK JOURNAL (IMMUTABLE) ==================== */}
        {activeTab === 'journal' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <h2 className="text-base font-bold text-slate-900">Immutable Stock Ledger (Rule 3)</h2>
              <p className="text-xs text-slate-500">
                Append-only log. Every purchase, sale, or correction is stored as a new entry.
              </p>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <tr>
                    <th className="p-3">Date</th>
                    <th className="p-3">Entry No</th>
                    <th className="p-3">Type</th>
                    <th className="p-3">Warehouse</th>
                    <th className="p-3 text-right">Quantity</th>
                    <th className="p-3 text-right">Unit Cost</th>
                    <th className="p-3">Reference / Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stockEntries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50/50">
                      <td className="p-3 text-slate-600">{formatDate(entry.created_at)}</td>
                      <td className="p-3 font-mono font-medium text-slate-900">{entry.entry_number}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          entry.quantity > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {entry.entry_type}
                        </span>
                      </td>
                      <td className="p-3">{entry.warehouse}</td>
                      <td className={`p-3 text-right font-bold font-mono ${
                        entry.quantity > 0 ? 'text-emerald-700' : 'text-red-700'
                      }`}>
                        {entry.quantity > 0 ? `+${entry.quantity}` : entry.quantity}
                      </td>
                      <td className="p-3 text-right font-mono">{formatINR(entry.unit_cost)}</td>
                      <td className="p-3 text-slate-500">{entry.notes || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ==================== TAB 5: AUDIT LOG ==================== */}
        {activeTab === 'audit' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <h2 className="text-base font-bold text-slate-900">System Audit Trail (Rule 5)</h2>
              <p className="text-xs text-slate-500">
                Every write operation across all tables is automatically recorded with timestamps and payload.
              </p>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <tr>
                    <th className="p-3">Timestamp</th>
                    <th className="p-3">Table</th>
                    <th className="p-3">Action</th>
                    <th className="p-3">Record ID</th>
                    <th className="p-3">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/50">
                      <td className="p-3 text-slate-600 font-mono">{formatDate(log.timestamp)}</td>
                      <td className="p-3 font-semibold text-slate-800">{log.table_name}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.action === 'CREATE' ? 'bg-emerald-100 text-emerald-800' :
                          log.action === 'UPDATE' ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {log.action}
                        </span>
                      </td>
                      <td className="p-3 font-mono text-[11px] text-slate-500">{log.record_id}</td>
                      <td className="p-3 font-mono text-[10px] text-slate-500 max-w-xs truncate">
                        {log.new_data || log.previous_data || '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-3 px-4 text-center text-xs text-slate-500">
        Tyrebuddy Business OS • Offline-First Retail Management (Gujarat 24) • Data secured locally in IndexedDB & D: Drive
      </footer>
    </div>
  );
};

export default App;
