// Tyrebuddy Business OS - Core Domain Models & Types

export type GSTRate = 5 | 12 | 18 | 28;

export type WarehouseType = 'Own' | 'Damaged' | 'Returns' | 'Amazon FBA';

export type DeliveryStatus = 'Pending' | 'Packed' | 'Shipped' | 'Delivered' | 'RTO' | 'Cancelled';

export type PaymentStatus = 'Paid' | 'Partial' | 'Unpaid' | 'COD';

export type CustomerType = 'B2B' | 'B2C';

export type StockJournalEntryType = 'PURCHASE_IN' | 'SALE_OUT' | 'RETURN_IN' | 'DAMAGE_OUT' | 'TRANSFER' | 'ADJUSTMENT';

// Rule 2: Multi-tenant from day 1 - org_id on every entity
export interface Organization {
  id: string;
  org_id: string;
  name: string;
  trade_name?: string;
  gstin: string; // e.g. 24XXXXX...
  state_code: string; // "24" for Gujarat
  address: string;
  city: string;
  pincode: string;
  phone: string;
  email?: string;
  created_at: string;
  updated_at: string;
}

// Rule 4: Variant attributes stored as JSON key-value
export interface ProductVariant {
  id: string;
  org_id: string;
  product_id: string;
  sku: string;
  barcode: string;
  title: string;
  attributes: Record<string, string>; // e.g. { "size": "26x1.95", "color": "Black", "type": "Tubeless" }
  mrp: number; // Maximum Retail Price (INR)
  selling_price_inclusive: number; // Custom price entry is GST-INCLUSIVE (Rule)
  hsn_code: string;
  gst_rate: GSTRate;
  cost_price: number; // Latest purchase price
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Product: Parent catalog item (can be simple, variant-based, or combo)
export interface Product {
  id: string;
  org_id: string;
  name: string;
  category: string;
  brand?: string;
  hsn_code: string;
  gst_rate: GSTRate;
  is_combo: boolean;
  // Rule: Combos - children keep own HSN + GST rate
  combo_items?: {
    variant_id: string;
    quantity: number;
    hsn_code: string;
    gst_rate: GSTRate;
    title: string;
  }[];
  is_active: boolean;
  is_deleted?: boolean;
  created_at: string;
  updated_at: string;
}

// Rule 3: Stock journal immutable — corrections are NEW rows.
// FIFO stock tracking: each incoming lot has a batch ID and remaining available qty.
export interface StockJournalEntry {
  id: string;
  org_id: string;
  entry_number: string;
  entry_type: StockJournalEntryType;
  variant_id: string;
  warehouse: WarehouseType;
  to_warehouse?: WarehouseType; // For transfers
  quantity: number; // positive for IN, negative or positive handled cleanly
  unit_cost: number; // Purchase cost for FIFO tracking
  reference_type?: 'ORDER' | 'PURCHASE' | 'CORRECTION' | 'RETURN';
  reference_id?: string;
  notes?: string;
  // FIFO lot remaining quantity (used for FIFO valuation)
  remaining_qty?: number;
  created_at: string; // ISO date string
}

// Customer Profile
export interface Customer {
  id: string;
  org_id: string;
  name: string;
  type: CustomerType;
  phone: string;
  email?: string;
  address?: string;
  city?: string;
  state: string; // e.g. "Gujarat"
  state_code: string; // "24" for Gujarat
  gstin?: string; // For B2B
  discount_percentage?: number; // B2B negotiated discount %
  credit_days?: number; // 30 days for B2B, 0 for B2C
  credit_limit?: number;
  is_deleted?: boolean;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  id: string;
  variant_id: string;
  product_name: string;
  sku: string;
  hsn_code: string;
  quantity: number;
  selling_price_inclusive: number; // User entered inclusive price
  taxable_value: number; // Back-calculated
  gst_rate: GSTRate;
  cgst_amount: number;
  sgst_amount: number;
  igst_amount: number;
  total_tax_amount: number;
  total_amount: number;
  fifo_cost_price?: number; // Recorded at dispatch for profit/COGS
}

export interface Order {
  id: string;
  org_id: string;
  order_number: string; // e.g. ORD-2026-0001 (resets April 1)
  invoice_number?: string; // e.g. INV-2026-0001
  customer_id: string;
  customer_name: string;
  customer_type: CustomerType;
  customer_phone: string;
  customer_state_code: string;
  is_inter_state: boolean; // true if customer_state_code !== '24'
  warehouse: WarehouseType;
  items: OrderItem[];
  subtotal_taxable: number;
  total_cgst: number;
  total_sgst: number;
  total_igst: number;
  total_tax: number;
  total_amount: number;
  // Plain language payment fields
  payment_status: PaymentStatus;
  amount_received: number; // Plain language instead of debit
  balance_due: number; // Plain language instead of credit balance
  // Internal tracking fields (NEVER shown on customer-facing invoice - Rule 9)
  delivery_status: DeliveryStatus;
  order_source?: string; // e.g. "Store Walk-in", "WhatsApp", "Phone"
  courier_name?: string;
  awb_number?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  is_deleted?: boolean;
}

// Rule 5: Every DB write logs to audit_log
export interface AuditLogEntry {
  id: string;
  org_id: string;
  table_name: string;
  record_id: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'BACKUP_RESTORE';
  previous_data?: string; // JSON string
  new_data?: string; // JSON string
  performed_by?: string;
  timestamp: string;
}

// Financial Year Sequence tracking
export interface NumberingSequence {
  id: string;
  org_id: string;
  entity_type: 'ORDER' | 'INVOICE' | 'JOURNAL';
  financial_year: string; // e.g. "2026"
  last_number: number;
}
