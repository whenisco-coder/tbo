// Utility functions for Tyrebuddy Business OS

import { GSTRate } from '../types';

/**
 * Format currency to Indian Rupees (₹) with Indian number formatting (lakhs, crores).
 * e.g. 150250.5 -> "₹1,50,250.50"
 */
export function formatINR(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return '₹0.00';
  }
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Format date strictly to "DD Mon YYYY" (e.g. "06 Oct 2026")
 */
export function formatDate(dateInput: string | Date | number): string {
  if (!dateInput) return '';
  const date = typeof dateInput === 'string' || typeof dateInput === 'number' ? new Date(dateInput) : dateInput;
  if (isNaN(date.getTime())) return '';

  const day = String(date.getDate()).padStart(2, '0');
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[date.getMonth()];
  const year = date.getFullYear();

  return `${day} ${month} ${year}`;
}

/**
 * Returns Indian Financial Year start year string.
 * Indian FY starts on April 1 and ends on March 31.
 * e.g., Date between 01-Apr-2026 and 31-Mar-2027 returns "2026".
 * Date before 01-Apr-2026 (e.g. 15-Jan-2026) returns "2025".
 */
export function getFinancialYear(date: Date = new Date()): string {
  const currentYear = date.getFullYear();
  const currentMonth = date.getMonth(); // 0-indexed: 0 = Jan, 3 = Apr

  if (currentMonth >= 3) {
    // April (3) to December (11)
    return String(currentYear);
  } else {
    // January (0) to March (2)
    return String(currentYear - 1);
  }
}

/**
 * Formats sequence numbers according to business rule:
 * Order no: ORD-2026-0001
 * Invoice no: INV-2026-0001
 */
export function formatSequenceNumber(prefix: 'ORD' | 'INV' | 'JRN', fy: string, sequence: number): string {
  const padded = String(sequence).padStart(4, '0');
  return `${prefix}-${fy}-${padded}`;
}

/**
 * Back-calculates GST from inclusive retail price.
 * Rule: Custom price entry is GST-INCLUSIVE.
 * Formula: Taxable Base = Inclusive Price / (1 + Rate / 100)
 */
export function calculateGSTFromInclusive(
  inclusivePrice: number,
  quantity: number,
  gstRate: GSTRate,
  customerStateCode: string = '24' // Default Gujarat (Code 24)
) {
  const totalGross = roundTwo(inclusivePrice * quantity);
  const rateFactor = 1 + gstRate / 100;
  
  const totalTaxable = roundTwo(totalGross / rateFactor);
  const totalTax = roundTwo(totalGross - totalTaxable);

  const isInterState = customerStateCode.trim() !== '24';

  let cgst = 0;
  let sgst = 0;
  let igst = 0;

  if (isInterState) {
    igst = totalTax;
  } else {
    cgst = roundTwo(totalTax / 2);
    sgst = roundTwo(totalTax - cgst); // Ensure exact sum matches totalTax
  }

  return {
    inclusiveUnitPrice: inclusivePrice,
    quantity,
    totalGross,
    taxableValue: totalTaxable,
    gstRate,
    isInterState,
    cgst,
    sgst,
    igst,
    totalTax,
  };
}

/**
 * Round accurately to 2 decimal places (paise)
 */
export function roundTwo(num: number): number {
  return Math.round((num + Number.EPSILON) * 100) / 100;
}
