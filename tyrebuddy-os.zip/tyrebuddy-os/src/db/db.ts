// Dexie.js IndexedDB configuration for Tyrebuddy Business OS
import Dexie, { type Table } from 'dexie';
import {
  Organization,
  Product,
  ProductVariant,
  StockJournalEntry,
  Customer,
  Order,
  AuditLogEntry,
  NumberingSequence,
} from '../types';
import { getFinancialYear, formatSequenceNumber } from '../utils/formatters';

export class TyrebuddyDatabase extends Dexie {
  organizations!: Table<Organization, string>;
  products!: Table<Product, string>;
  variants!: Table<ProductVariant, string>;
  stock_journal!: Table<StockJournalEntry, string>;
  customers!: Table<Customer, string>;
  orders!: Table<Order, string>;
  audit_log!: Table<AuditLogEntry, string>;
  sequences!: Table<NumberingSequence, string>;

  constructor() {
    super('TyrebuddyOS_DB');

    // Rule 2: Multi-tenant from day 1: org_id on every table
    this.version(1).stores({
      organizations: 'id, org_id, gstin, created_at',
      products: 'id, org_id, name, category, hsn_code, is_active, is_deleted',
      variants: 'id, org_id, product_id, sku, barcode, is_active',
      stock_journal: 'id, org_id, entry_number, entry_type, variant_id, warehouse, created_at',
      customers: 'id, org_id, name, phone, type, state_code, gstin, is_deleted',
      orders: 'id, org_id, order_number, invoice_number, customer_id, warehouse, payment_status, delivery_status, created_at, is_deleted',
      audit_log: 'id, org_id, table_name, record_id, action, timestamp',
      sequences: 'id, [org_id+entity_type+financial_year]',
    });

    // Rule 5: Every DB write logs to audit_log
    this.setupAuditHooks();
  }

  private setupAuditHooks() {
    const auditableTables: Array<keyof TyrebuddyDatabase> = [
      'organizations',
      'products',
      'variants',
      'stock_journal',
      'customers',
      'orders',
    ];

    auditableTables.forEach((tblName) => {
      const table = (this as any)[tblName] as Table<any, string>;
      if (!table) return;

      // Log Creations
      table.hook('creating', (_primKey, obj, trans) => {
        const auditEntry: AuditLogEntry = {
          id: `AUD-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          org_id: obj.org_id || 'default_org',
          table_name: String(tblName),
          record_id: obj.id || String(_primKey),
          action: 'CREATE',
          new_data: JSON.stringify(obj),
          timestamp: new Date().toISOString(),
        };
        // Write to audit log within same transaction
        trans.table('audit_log').add(auditEntry);
      });

      // Log Updates
      table.hook('updating', (mods, primKey, obj, trans) => {
        const auditEntry: AuditLogEntry = {
          id: `AUD-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          org_id: obj.org_id || 'default_org',
          table_name: String(tblName),
          record_id: String(primKey),
          action: 'UPDATE',
          previous_data: JSON.stringify(obj),
          new_data: JSON.stringify({ ...obj, ...mods }),
          timestamp: new Date().toISOString(),
        };
        trans.table('audit_log').add(auditEntry);
      });

      // Log Deletions
      table.hook('deleting', (primKey, obj, trans) => {
        const auditEntry: AuditLogEntry = {
          id: `AUD-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          org_id: obj.org_id || 'default_org',
          table_name: String(tblName),
          record_id: String(primKey),
          action: 'DELETE',
          previous_data: JSON.stringify(obj),
          timestamp: new Date().toISOString(),
        };
        trans.table('audit_log').add(auditEntry);
      });
    });
  }

  /**
   * Generates next sequence number resetting April 1 of each year.
   * e.g. ORD-2026-0001 or INV-2026-0001
   */
  async getNextSequence(orgId: string, type: 'ORDER' | 'INVOICE' | 'JOURNAL'): Promise<string> {
    const fy = getFinancialYear();
    const prefix = type === 'ORDER' ? 'ORD' : type === 'INVOICE' ? 'INV' : 'JRN';

    return await this.transaction('rw', this.sequences, async () => {
      const existing = await this.sequences
        .where({ org_id: orgId, entity_type: type, financial_year: fy })
        .first();

      let nextNum = 1;
      if (existing) {
        nextNum = existing.last_number + 1;
        await this.sequences.update(existing.id, { last_number: nextNum });
      } else {
        await this.sequences.add({
          id: `${orgId}_${type}_${fy}`,
          org_id: orgId,
          entity_type: type,
          financial_year: fy,
          last_number: nextNum,
        });
      }

      return formatSequenceNumber(prefix, fy, nextNum);
    });
  }

  /**
   * Rule 7: Never lose data.
   * Export all local database content as a structured JSON object for D: drive storage.
   */
  async exportFullBackup(orgId?: string) {
    const backup = {
      version: 1,
      appName: 'Tyrebuddy Business OS',
      exportedAt: new Date().toISOString(),
      organizations: await this.organizations.toArray(),
      products: await this.products.toArray(),
      variants: await this.variants.toArray(),
      stock_journal: await this.stock_journal.toArray(),
      customers: await this.customers.toArray(),
      orders: await this.orders.toArray(),
      audit_log: await this.audit_log.toArray(),
      sequences: await this.sequences.toArray(),
    };

    if (orgId) {
      backup.products = backup.products.filter(p => p.org_id === orgId);
      backup.variants = backup.variants.filter(v => v.org_id === orgId);
      backup.stock_journal = backup.stock_journal.filter(s => s.org_id === orgId);
      backup.customers = backup.customers.filter(c => c.org_id === orgId);
      backup.orders = backup.orders.filter(o => o.org_id === orgId);
    }

    return backup;
  }

  /**
   * Restore full backup from JSON
   */
  async importFullBackup(backupData: any) {
    if (!backupData || !backupData.appName) {
      throw new Error('Invalid backup file format');
    }

    await this.transaction(
      'rw',
      [
        this.organizations,
        this.products,
        this.variants,
        this.stock_journal,
        this.customers,
        this.orders,
        this.audit_log,
        this.sequences,
      ],
      async () => {
        if (backupData.organizations?.length) await this.organizations.bulkPut(backupData.organizations);
        if (backupData.products?.length) await this.products.bulkPut(backupData.products);
        if (backupData.variants?.length) await this.variants.bulkPut(backupData.variants);
        if (backupData.stock_journal?.length) await this.stock_journal.bulkPut(backupData.stock_journal);
        if (backupData.customers?.length) await this.customers.bulkPut(backupData.customers);
        if (backupData.orders?.length) await this.orders.bulkPut(backupData.orders);
        if (backupData.sequences?.length) await this.sequences.bulkPut(backupData.sequences);

        await this.audit_log.add({
          id: `AUD-RESTORE-${Date.now()}`,
          org_id: backupData.organizations?.[0]?.org_id || 'default_org',
          table_name: 'SYSTEM',
          record_id: 'ALL',
          action: 'BACKUP_RESTORE',
          new_data: JSON.stringify({ restoreDate: new Date().toISOString() }),
          timestamp: new Date().toISOString(),
        });
      }
    );
  }
}

export const db = new TyrebuddyDatabase();
