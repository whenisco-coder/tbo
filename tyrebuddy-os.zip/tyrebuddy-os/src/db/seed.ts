import { db } from './db';
import { Organization, Product, ProductVariant, Customer, StockJournalEntry } from '../types';

export const DEFAULT_ORG_ID = 'tyrebuddy_gujarat_main';

export async function initializeDatabaseIfEmpty() {
  const orgCount = await db.organizations.count();
  if (orgCount > 0) return;

  const defaultOrg: Organization = {
    id: DEFAULT_ORG_ID,
    org_id: DEFAULT_ORG_ID,
    name: 'Tyrebuddy Bicycle Accessories',
    trade_name: 'Tyrebuddy Retail & Wholesale',
    gstin: '24AAACT1234F1Z8', // Gujarat State Code 24
    state_code: '24',
    address: 'Shop No. 12, Cycle Market, Ring Road',
    city: 'Ahmedabad',
    pincode: '380002',
    phone: '+91 98765 43210',
    email: 'contact@tyrebuddy.in',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  await db.organizations.add(defaultOrg);

  // Sample Product & Variant
  const productId = 'prod_ralson_26';
  const variantId = 'var_ralson_26_black';

  const sampleProduct: Product = {
    id: productId,
    org_id: DEFAULT_ORG_ID,
    name: 'Ralson MTB 26x1.95 Bicycle Tyre',
    category: 'Tyres',
    brand: 'Ralson',
    hsn_code: '40115000',
    gst_rate: 18,
    is_combo: false,
    is_active: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const sampleVariant: ProductVariant = {
    id: variantId,
    org_id: DEFAULT_ORG_ID,
    product_id: productId,
    sku: 'RAL-26-BLK',
    barcode: '8901234567890',
    title: 'Ralson MTB 26x1.95 (Black - Nylon)',
    attributes: { size: '26x1.95', color: 'Black', tread: 'MTB Knobby' },
    mrp: 499,
    selling_price_inclusive: 450, // Rule: Custom price entry is GST-INCLUSIVE
    hsn_code: '40115000',
    gst_rate: 18,
    cost_price: 280,
    is_active: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  await db.products.add(sampleProduct);
  await db.variants.add(sampleVariant);

  // Initial Stock (Rule 3: Stock journal immutable)
  const initialStock: StockJournalEntry = {
    id: `JRN-${Date.now()}`,
    org_id: DEFAULT_ORG_ID,
    entry_number: 'JRN-2026-0001',
    entry_type: 'PURCHASE_IN',
    variant_id: variantId,
    warehouse: 'Own',
    quantity: 50,
    unit_cost: 280,
    remaining_qty: 50,
    reference_type: 'PURCHASE',
    notes: 'Opening stock lot for Ahmedabad retail shop',
    created_at: new Date().toISOString(),
  };

  await db.stock_journal.add(initialStock);

  // Sample Customers (B2B Gujarat and B2C)
  const sampleB2BCustomer: Customer = {
    id: 'cust_b2b_patel',
    org_id: DEFAULT_ORG_ID,
    name: 'Patel Cycle Stores',
    type: 'B2B',
    phone: '+91 98250 11223',
    city: 'Surat',
    state: 'Gujarat',
    state_code: '24',
    gstin: '24ABCP9876Q1Z2',
    discount_percentage: 10,
    credit_days: 30, // Rule: B2B customers 30-day credit
    credit_limit: 50000,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const sampleB2CCustomer: Customer = {
    id: 'cust_b2c_walkin',
    org_id: DEFAULT_ORG_ID,
    name: 'Walk-in Retail Customer',
    type: 'B2C',
    phone: '+91 99000 00000',
    city: 'Ahmedabad',
    state: 'Gujarat',
    state_code: '24',
    credit_days: 0, // Rule: B2C same-day payment
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  await db.customers.add(sampleB2BCustomer);
  await db.customers.add(sampleB2CCustomer);
}
